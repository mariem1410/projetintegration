const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');

// Route pour obtenir tous les profils
router.get('/', profileController.getAll);

// Route pour obtenir un profil spécifique
router.get('/:idProfile', profileController.getById);

// Route pour créer un nouveau profil
router.post('/', profileController.create);

// Route pour mettre à jour un profil
router.put('/:idProfile', profileController.update);

// Route pour supprimer un profil
router.delete('/:idProfile', profileController.delete);

module.exports = router;
