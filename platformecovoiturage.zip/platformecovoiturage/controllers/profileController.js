const Profile = require('../models/profileModel'); // Import du modèle Sequelize

// Obtenir tous les profils
exports.getAll = async (req, res) => {
    try {
        const profiles = await Profile.findAll();
        res.status(200).json(profiles);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erreur lors de la récupération des profils.' });
    }
};

// Obtenir un profil par ID
exports.getById = async (req, res) => {
    const { idProfile } = req.params;
    try {
        const profile = await Profile.findByPk(idProfile);
        if (!profile) {
            return res.status(404).json({ message: 'Profil non trouvé.' });
        }
        res.status(200).json(profile);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erreur lors de la récupération du profil.' });
    }
};

// Créer un nouveau profil
exports.create = async (req, res) => {
    const { idProfile, nomPrenom, photo, preferenceVoyage } = req.body;
    try {
        const newProfile = await Profile.create({ idProfile, nomPrenom, photo, preferenceVoyage });
        res.status(201).json({ message: 'Profil créé avec succès.', profile: newProfile });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erreur lors de la création du profil.' });
    }
};

// Mettre à jour un profil
exports.update = async (req, res) => {
    const { idProfile } = req.params;
    const { nomPrenom, photo, preferenceVoyage } = req.body;
    try {
        const profile = await Profile.findByPk(idProfile);
        if (!profile) {
            return res.status(404).json({ message: 'Profil non trouvé.' });
        }

        profile.nomPrenom = nomPrenom || profile.nomPrenom;
        profile.photo = photo || profile.photo;
        profile.preferenceVoyage = preferenceVoyage || profile.preferenceVoyage;
        await profile.save();

        res.status(200).json({ message: 'Profil mis à jour avec succès.', profile });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erreur lors de la mise à jour du profil.' });
    }
};

// Supprimer un profil
exports.delete = async (req, res) => {
    const { idProfile } = req.params;
    try {
        const profile = await Profile.findByPk(idProfile);
        if (!profile) {
            return res.status(404).json({ message: 'Profil non trouvé.' });
        }

        await profile.destroy();
        res.status(200).json({ message: 'Profil supprimé avec succès.' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erreur lors de la suppression du profil.' });
    }
};
