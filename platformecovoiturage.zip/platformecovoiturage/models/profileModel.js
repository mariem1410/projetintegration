const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Profile = sequelize.define('ProfileModel', {
    idProfile: {
        type: DataTypes.STRING,
        primaryKey: true,
        allowNull: false,
    },
    nomPrenom: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    photo: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    preferenceVoyage: {
        type: DataTypes.STRING,
        allowNull: false,
    },
}, {
    tableName: 'profiles',
    timestamps: false,
});

module.exports = Profile;
