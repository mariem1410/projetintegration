const express = require('express');
const bodyParser = require('body-parser');
const profileRoutes = require('./routes/profileRoutes');

const app = express();
const port = 5000;

// Middlewarec
app.use(bodyParser.json());

// Routes
app.use('/profiles', profileRoutes);

// Démarrer le serveur
app.listen(port, () => {
    console.log(`Serveur démarré sur http://localhost:${port}`);
});
