const { Sequelize } = require('sequelize');

// Connexion à la base de données
const sequelize = new Sequelize('profilesdb', 'root', 'yes', {
    host: 'localhost', // Pas "http://localhost"
    port: 3306,        // Ajoutez le port si nécessaire
    dialect: 'mysql',
});

// Test de la connexion
sequelize.authenticate()
    .then(() => console.log('Connexion à la base de données réussie.'))
    .catch(err => console.error('Erreur de connexion :', err.message));

// Exportation du module
module.exports = sequelize;
